var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":[],"propsByKey":{}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var box1 = createSprite(35, 200, 100, 100);
var box2 = createSprite(370, 200, 100, 100);
var life = 0;
var ball = createSprite(30, 200, 20, 20);
var line1 = createSprite(10, 150, 150, 5);
var line2 = createSprite(10, 250, 150, 5);
var line3 = createSprite(82, 330, 5, 160);
var line4 = createSprite(82, 70, 5, 160);
var line5 = createSprite(393, 150, 150, 5);
var line6 = createSprite(393, 250, 150, 5);
var line7 = createSprite(320, 330, 5, 160);
var line8 = createSprite(320, 70, 5, 160);
var ball1 = createSprite(95, 200, 20, 20);
var ball2 = createSprite(125, 200, 20, 20);
var ball3 = createSprite(155, 200, 20, 20);
var ball4 = createSprite(185, 200, 20, 20);
var ball5 = createSprite(215, 200, 20, 20);
var ball6 = createSprite(245, 200, 20, 20);
var ball7 = createSprite(275, 200, 20, 20);
var ball8 = createSprite(305, 200, 20, 20);



box1.shapeColor="lightblue";
box2.shapeColor="yellow";

ball.shapeColor="blue";
line1.shapeColor="black";
line2.shapeColor="black";
line3.shapeColor="black";
line4.shapeColor="black";
line5.shapeColor="black";
line6.shapeColor="black";
line7.shapeColor="black";
line8.shapeColor="black";

ball1.shapeColor="red";
ball2.shapeColor="red";
ball3.shapeColor="red";
ball4.shapeColor="red";
ball5.shapeColor="red";
ball6.shapeColor="red";
ball7.shapeColor="red";
ball8.shapeColor="red";

ball1.velocityY=+10;
ball2.velocityY=-10;
ball3.velocityY=+10;
ball4.velocityY=-10;
ball5.velocityY=+10;
ball6.velocityY=-10;
ball7.velocityY=+10;
ball8.velocityY=-10;



function draw() {
  background("white");
  drawSprites();
  createEdgeSprites();
  
  textSize(20);
  fill("black");
  text("Lives: " + life,8,130);
  
  ball1.bounceOff(edges);
ball2.bounceOff(edges);
ball3.bounceOff(edges);
ball4.bounceOff(edges);
ball5.bounceOff(edges);
ball6.bounceOff(edges);
ball7.bounceOff(edges);
ball8.bounceOff(edges);

ball.collide(line1);
ball.collide(line2);
ball.collide(line3);
ball.collide(line4);
ball.collide(line5);
ball.collide(line6);
ball.collide(line7);
ball.collide(line8);
ball.collide(edges);


if (keyDown(UP_ARROW)) {
  ball.y=ball.y-5;
}
if (keyDown("down")) {
  ball.y=ball.y+5;
}
if(keyDown(RIGHT_ARROW)){
  ball.x=ball.x+5;
}
if(keyDown(LEFT_ARROW)){
  ball.x=ball.x-5;
}

if (ball.isTouching(ball1) || ball.isTouching(ball2) || ball.isTouching(ball3) || ball.isTouching(ball4) || ball.isTouching(ball5) || ball.isTouching(ball6) || ball.isTouching(ball7) || ball.isTouching(ball8)) {
  ball.y = 200;
  ball.x = 30;
  life += life=1;
}
if (ball.isTouching(box2)) {
  textSize(40);
  fill("black");
  text("YOU WIN!",100,200);
ball1.destroy();
ball2.destroy();
ball3.destroy();
ball4.destroy();
ball5.destroy();
ball6.destroy();
ball7.destroy();
ball8.destroy();
}


 
  
}
// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
